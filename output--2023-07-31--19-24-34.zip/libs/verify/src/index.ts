//implements F014
export * from './lib/lib.routes';

export * from './lib/verify/verify.component';
