export interface ChangePasswordDTO {
  oldPassword: string;
  newPassword: string;
}
