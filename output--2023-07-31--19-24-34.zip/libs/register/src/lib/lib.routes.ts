//implements F010
import { Route } from '@angular/router';
import { RegisterComponent } from './register/register.component';

export const registerRoutes: Route[] = [
  {
    path: '',
    component: RegisterComponent,
  },
];
