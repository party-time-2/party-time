//implements F010
export * from './lib/+state/register.state';
export * from './lib/lib.routes';
export * from './lib/register/register.component';
