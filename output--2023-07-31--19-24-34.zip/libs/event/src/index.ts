export * from './lib/lib.routes';

export * from './lib/event/event.component';
